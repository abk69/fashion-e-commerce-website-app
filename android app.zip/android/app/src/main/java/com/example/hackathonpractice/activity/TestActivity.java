package com.example.hackathonpractice.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.hackathonpractice.R;

public class TestActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
    }
}